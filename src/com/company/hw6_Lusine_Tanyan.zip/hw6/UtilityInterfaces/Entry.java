package com.company.hw6.UtilityInterfaces;

public interface Entry<K, V> {
    K getKey();

    V getValue();
}
